/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "BluetoothComms.h"
#include "MessageConstructor.h"


//uint8 BluetoothUART_rxBuffer[BluetoothUART_RX_BUFFER_SIZE];



uint8_t bluetoothRecMsgByte;
uint8_t bluetoothRecMsgByteCount = 0;

const uint8_t msgStartSeq[2] = {0xF, 0xA};
const uint8_t msgEndSeq[2] =  {0xC, 0xE};


TaskHandle_t xHandle = NULL;
TickType_t bluetoothRecTimeout_ms = 5;;



TickType_t oldTickCount = 0;
TickType_t newTickCount = 0;

unsigned long bluetoothLastRecMsg_ms = 0;
uint8_t bluetoothDataAvailable = 0;

static void TaskBluetoothComms( void *pvParameters )
{
	
    (void)pvParameters;
    
    //IntBluetoothUART_Start();
    
    BluetoothUART_Start();
    BluetoothUART_ClearRxBuffer();
    
    oldTickCount = xTaskGetTickCount(); 
    
    uint16_t errorLog = 0;
    uint8_t readData = 0;
    
	for( ;; )
	{
        BaseType_t xHigherPriorityTaskWoken = pdFALSE;
     
        ulTaskNotifyTake( pdTRUE, portMAX_DELAY/*pdMS_TO_TICKS(bluetoothRecTimeout_ms)*/ );
     
        if( 1 )
        {
            BluetoothUART_ClearRxBuffer();
            while(bluetoothRecMsgByteCount < 20)
            {
                errorLog = BluetoothUART_GetByte() >> 8;
                readData = errorLog << 8;
                BluetoothUART_rxBuffer[bluetoothRecMsgByteCount] = BluetoothUART_GetByte();
                bluetoothRecMsgByteCount++;
            }
        
           
            bluetoothRecMsgByteCount++;
            continue;
            
        }
        
        bluetoothDataAvailable = 0;
        
        //bluetoothRecUserBuffer[bluetoothRecMsgByteCount] = BluetoothUART_GetByte();
        
        bluetoothRecMsgByteCount++;
    }
}

TaskHandle_t getBluetoothCommsTaskHandle()
{
    
    return xHandle; 
}


void startTaskBluetoothComms()
{
    
    /* Create the task, storing the handle. */ 
	xTaskCreate(
		TaskBluetoothComms,      /* Function that implements the task. */ 
		"taskUserCodeGenerator",    /* Text name for the task. */ 
		128,                        /* Stack size in words, not bytes. */ 
		( void * ) 1,               /* Parameter passed into the task. */ 
		tskIDLE_PRIORITY,           /* Priority at which the task is created. */ 
	&xHandle );                     /* Used to pass out the created task's handle. */ 
    
}



/* [] END OF FILE */
